/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoy.sb;

import model.UserGroup;
import view.MainContainer;

/**
 *
 * @author Y0239881
 */
public class Global {
    public static boolean loggedIn = false;
    public static String loggedInUser = "";
    public static MainContainer container = null;
    public static UserGroup group = null;
}
