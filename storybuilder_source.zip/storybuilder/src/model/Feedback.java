/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Y0239881
 */
public enum Feedback {
    HAPPY, 
    SAD, 
    MAD, 
    CONFUSED 
}
